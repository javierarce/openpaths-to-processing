# openpaths-to-processing

Processing sketch that visualices the points and paths obtained using the OpenPaths app.
